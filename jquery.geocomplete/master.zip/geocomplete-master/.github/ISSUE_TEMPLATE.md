Please note: This project is not maintained anymore!
Feel free to discuss issues here but please do not expect new features or changes in the default behavior.
