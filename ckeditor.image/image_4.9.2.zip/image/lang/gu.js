/*
Copyright (c) 2003-2018, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'image', 'gu', {
	alt: 'ઑલ્ટર્નટ ટેક્સ્ટ',
	border: 'બોર્ડર',
	btnUpload: 'આ સર્વરને મોકલવું',
	button2Img: 'તમારે ઈમેજ બટનને સાદી ઈમેજમાં બદલવું છે.',
	hSpace: 'સમસ્તરીય જગ્યા',
	img2Button: 'તમારે સાદી ઈમેજને ઈમેજ બટનમાં બદલવું છે.',
	infoTab: 'ચિત્ર ની જાણકારી',
	linkTab: 'લિંક',
	lockRatio: 'લૉક ગુણોત્તર',
	menu: 'ચિત્રના ગુણ',
	resetSize: 'રીસેટ સાઇઝ',
	title: 'ચિત્રના ગુણ',
	titleButton: 'ચિત્ર બટનના ગુણ',
	upload: 'અપલોડ',
	urlMissing: 'ઈમેજની મૂળ URL છે નહી.',
	vSpace: 'લંબરૂપ જગ્યા',
	validateBorder: 'બોર્ડેર આંકડો હોવો જોઈએ.',
	validateHSpace: 'HSpaceઆંકડો હોવો જોઈએ.',
	validateVSpace: 'VSpace આંકડો હોવો જોઈએ. '
} );
